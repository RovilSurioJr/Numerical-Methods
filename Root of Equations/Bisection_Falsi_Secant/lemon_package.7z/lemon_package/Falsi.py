import numpy as np

def falsi(func,a,b,n_roots,epochs,n_move,tol = 1.0e-06):
  x_roots = []
  fpoint = []
  spoint = []
 
  for i in range(n_move):
    a+=0.25
    b+=0.25
    fpoint.append(a)
    spoint.append(b)
  for (a,b) in zip (fpoint,spoint):
    y1, y2 = func(a), func(b)
    root = None 
    pos = 0
    if np.allclose(0,y1): root = a
    elif np.allclose(0,y2): root = b
    elif np.sign(y1) == np.sign(y2):
      pass #Roots not in this interval
    else:
      for pos in range(epochs):
        c = b - (func(b)*(b-a))/(func(b)-func(a)) ##false root
        if np.allclose(0,func(c), tol):
          root = c
          x_roots.append(root)
          final_roots = np.unique(np.around(x_roots,3))
          final_roots = final_roots[:n_roots]
          break
        if np.sign(func(a)) != np.sign(func(c)): b,y2 = c,func(c)
        else: a,y1 = c,func(c) 
  return final_roots, pos
    

