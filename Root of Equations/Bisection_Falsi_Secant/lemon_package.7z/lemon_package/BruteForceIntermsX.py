import numpy as np

def b_forcex(funcs,no_roots,epochs,x0 = 0):
  roots = []
  for func in funcs:
    x0=0
    for epoch in range(epochs):
      x_prime = func(x0) 
      if np.allclose(x0, x_prime):
        roots.append(x0)
        final_roots = np.unique(np.around(roots,3))
        end_epoch = epoch
        break
      x0 = x_prime
  if len(final_roots) != 0:
    return final_roots, end_epoch
  else:
    final_roots = "Roots cannot be found"
    end_epoch = -1
    return final_roots, end_epoch
