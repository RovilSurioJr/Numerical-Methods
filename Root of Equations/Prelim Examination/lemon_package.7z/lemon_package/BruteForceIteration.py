import numpy as np
import math

def b_force(func,no_roots,epochs,x0,x1,tol = 1e-5):
  roots = []
  end_epoch = 0
  for epoch in range(epochs):
    if np.allclose(0,func(x0),tol):
      roots.append(x0)
      end_epoch = epoch
      if len(roots) == no_roots:
        break
    x0+=1e-4
  for epoch in range(epochs):
    if np.allclose(0,func(x1),tol):
      roots.append(x1)
      final_roots = np.unique(np.around(roots,3))
      end_epoch = epoch
      if len(roots) == no_roots:
        break
    x1-=1e-4
  if len(roots) != 0:
    return final_roots, end_epoch
  else:
    final_roots = "Roots cannot be found"
    end_epoch = -1
    return final_roots,end_epoch
