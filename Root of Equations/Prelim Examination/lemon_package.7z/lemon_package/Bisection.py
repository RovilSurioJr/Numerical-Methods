import numpy as np

def bisection(func,i1,i2,n_roots,epochs,n_move,tol = 1.0e-06,):
  x_roots = []
  fpoint = []
  spoint = []
  
  for i in range(n_move):
    i1+=0.25
    i2+=0.25
    fpoint.append(i1)
    spoint.append(i2)
  
  for (i1,i2) in zip (fpoint,spoint):
    y1, y2 = func(i1), func(i2)
    root = None
    end_bisect = 0
    if np.sign(y1) == np.sign(y2):
      pass #Roots not in this interval
    else:
      for bisect in range(epochs):
        midp = np.mean([i1,i2])
        y_mid = func(midp)
        y1 = func(i1)
        if np.allclose(0,y1, tol):
          root = i1
          x_roots.append(root)
          final_roots = np.unique(np.around(x_roots,3))
          final_roots = final_roots[:n_roots]
          end_bisect = bisect
          break
        if np.sign(y1) != np.sign(y_mid): #root is in first-half interval
          i2 = midp
        else: #root is in second-half interval
          i1 = midp 

  return final_roots,end_bisect

