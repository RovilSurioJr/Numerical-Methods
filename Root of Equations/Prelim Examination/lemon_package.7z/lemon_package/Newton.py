import numpy as np

def derivative(f,x,dx = 1e-6): 
  diff =  f(x+dx)-f(x-dx)  
  return diff/(2*dx)

def newton(func,n_roots,epochs, tol = 1.0e-05,inits = np.arange(-5,5)):
  #np.seterr(divide='ignore', invalid='ignore') 
  x_roots = []
  for init in inits:
    x=init
    for epoch in range(epochs):
      f_prime = derivative(func,x)
      x_new = x - (func(x)/f_prime)
      if np.allclose(x, x_new, tol):
        x_roots.append(x)
        final_roots = np.unique(np.around(x_roots,3))
        final_roots = final_roots[:n_roots]
        break
      x = x_new
  return final_roots, epoch  
