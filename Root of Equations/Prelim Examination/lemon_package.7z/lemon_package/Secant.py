import numpy as np

def secant(func,a,b,n_roots,epochs,n_move,tol = 1.0e-06):
  x_roots = []
  fpoint = []
  spoint = []
  
  for i in range(n_move):
    a+=0.25
    b+=0.25
    fpoint.append(a)
    spoint.append(b)

  for (a,b) in zip (fpoint,spoint):
    root = None
    end_epoch =  0
    for epoch in range(epochs):
      c = b - (func(b)*(b-a))/(func(b)-func(a))
      if np.allclose(b,c): 
        root = c
        x_roots.append(root)
        final_roots = np.unique(np.around(x_roots,3))
        final_roots = final_roots[:n_roots]
        end_epoch = epoch
        break
      else:
        a,b = b,c
  
  return final_roots, end_epoch
